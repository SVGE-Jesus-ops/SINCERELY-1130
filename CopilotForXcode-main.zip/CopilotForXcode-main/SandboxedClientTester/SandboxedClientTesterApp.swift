import SwiftUI

@main
struct SandboxedClientTesterApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
