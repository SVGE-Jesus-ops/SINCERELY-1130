import JSONRPC
import LanguageServerProtocol

public typealias ShowMessageRequest = JSONRPCRequest<ShowMessageRequestParams>
